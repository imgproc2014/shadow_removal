% Given dx dy horizental and vertical image derivatives reconstruct image.
% Look at Yair's artice 'Deriving intrinsic images from image sequences'
% page3 to understand the equations.
% here we do the convolutions using FFT2.


function [im]=reconsEdge3(dx,dy,invKhat)



im=zeros(size(dx));
[sx,sy]=size(dx);
mxsize=max(sx,sy);

if ~exist('invKhat')
  [g,k]=invDel2(2*mxsize);
  G=fft2(g);   %fourier for convolotion  G
end

%%
%%sigma(6) fnr*r_n
imX=conv2(dx,fliplr([1 -1]),'same');
imY=conv2(dy,flipud([1;-1]),'same');

imS=imX+imY;

%%

imShat=fft2(imS,2*mxsize,2*mxsize);
im=real(ifft2(G.*imShat));       %r , equation(6) page 3.
im=im(mxsize+1:mxsize+sx,mxsize+1:mxsize+sy);

end



