function    facePts = getFacePts(faceFileName, faceImage)
% facePts = getFacePts(faceFileName)
%This routine outputs coordinates of 12 points marking facial features in image.
%
%faceFileName � a string representing the image file name without extension
%
%facePts � a 24x1 vector of coordinates of the form [x1,y1,x2,y2�.]T
%

%Checking if points already marked and there is a .mat file including it.
%global image_prefix;

if(exist ([faceFileName '.mat'],'file'))
    %loading points from the file we found.
    load ([faceFileName '.mat'],'facePts');
    
    %no such file,we need to mark 12 points in the image.
else
    %disp 'Please click on the input image as marked here:'
    %imshow( imread('image001.tif'));
    %pause;
    imshow(faceImage,[]);
    [X,Y]= ginput(12);
    disp 'points has been saved'
    %closeing last 2 figures.
    close;
    
    facePts=[X.';Y.'];
    facePts=facePts(:);
    %saving marked points into .mat file.
    save ([faceFileName '.mat'],'facePts');
end
end
