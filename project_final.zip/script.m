

% load face images
global image_prefix;
image_prefix = 'facemaroun/ok/';
files = dir([image_prefix '*.pgm']);

if numel(files) == 0
    error('cannot find files in given directory: "%s".', [pwd '\' image_prefix]);
end

num_faces = numel(files);
faces = cell(1, num_faces);
first_im_size = size(imread([image_prefix files(1).name]));

for i = 1:num_faces
    temp = imread([image_prefix files(i).name]);
    temp = im2double(temp(:,:,1));
    temp2 = zeros(500);
    temp2(1:size(temp,1),1:size(temp,2)) = temp;
    faces{i} = temp2;
end

wFaces = warpSequenceToFirst(files, faces);

imageR = removeShadow(wFaces);
imageR = imageR(1:first_im_size(1),1:first_im_size(2));

imshow(imageR,[]);
pause;