function    T = findTransform (pointsSet1,pointsSet2)

   pointsSet11=pointsSet1;  

i=1;
    templ1=[pointsSet11(i),pointsSet11(i+1),0,0,1,0] ;
    templ2=[0,0,pointsSet11(i),pointsSet11(i+1),0,1];
    temp=[templ1;templ2];
    X=temp;

    for j=3:2:numel(pointsSet1)-1,
    templ1=[pointsSet11(j),pointsSet11(j+1),0,0,1,0];
    templ2=[0,0,pointsSet11(j),pointsSet11(j+1),0,1];
    temp=[templ1;templ2];
    X=[X;temp];
    end
    Tv=pinv(X)*pointsSet2;
    
    
       T4=reshape(Tv.',2,[]) ;
       T4=T4';
       T4r=(T4(end,:))';
       T4(end,:)=[];
       T4=[T4 T4r];
       T4=[T4;[0,0,1]];
       T=T4;
    end


