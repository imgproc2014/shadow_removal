% We implement equation(7) page 3 in the article, 
%and return invK which is 'g'.
  

function [g,K]=invDel2(isize)

 %sigma(7) fnr*fn for horizental and  vertical derivative fileters
 K=zeros(isize);
 K(isize/2,isize/2)=4;
 K(isize/2+1,isize/2)=-1;
 K(isize/2,isize/2+1)=-1;
 K(isize/2-1,isize/2)=-1;
 K(isize/2,isize/2-1)=-1; 
 
 Khat=fft2(K);  %fourier for sum in equation(7) page3
 
 %add 1 to inverse
 I=find(Khat==0);   % find all zeros in Khat
 Khat(I)=1;     % put 1 where all zeros 
 invKhat=1./Khat;   % inverse
 invKhat(I)=0;  %dec the effect of 1 added
 
 invK=ifft2(invKhat);
 invK=real(invK);
  %tryk=pinv(K);
 % invK and delta are not in the same dim, so we convolve
 % and then use transform fourier
 g=conv2(invK,[1 0 0 ;0 0 0; 0 0 0 ],'same');  %just
 
end