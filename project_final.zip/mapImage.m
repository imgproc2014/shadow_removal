function    newIm = mapImage (im,T,sizeOutIm)
%newIm = mapImage (im,T,sizeOutIm)
% Maps image im using the affine transform T into an image of size sizeOutIm.
% Uses Bilinear Interpolation.
%
% im - a grayscale image array in the range [0..255].
% T  - a 3x3 matrix representing an affine transformation.
% sizeOutIm � a vector [numRows, numCols] representing the size of the output image.
%
% newIm - a grayscale image in the range [0..255] of size sizeOutIm containing the
% affine transformed image.

if isa(im, 'double')
    im = im * 255;
end

%creating empty output image.
c=sizeOutIm(1);r=sizeOutIm(2);
h=ones(c,r);
[X,Y]=meshgrid(1:c,1:r);

% calculate source coordinates
sourceCoor = inv(T) * [X(:) Y(:) h(:)]' ;
OORC=0;%OutOfRangeColor

NWx=floor(sourceCoor(1,:));
NWy=floor(sourceCoor(2,:));
NEx=floor(sourceCoor(1,:))+1;
NEy=floor(sourceCoor(2,:));
SWx=floor(sourceCoor(1,:));
SWy=floor(sourceCoor(2,:))+1;
SEx=floor(sourceCoor(1,:))+1;
SEy=floor(sourceCoor(2,:))+1;
Dx=(sourceCoor(1,:))-floor(sourceCoor(1,:));
Dy=(sourceCoor(2,:))-floor(sourceCoor(2,:));

%checking SE out of range pixels
indxSE=find(SEx<1 | SEx>r);
SEx(indxSE)=1; SEy(indxSE)=1;
indySE=find(SEy<1 | SEy>c);
SEx(indySE)=1; SEy(indySE)=1;

%picking of colors from SE pixel.
SE=im((SEx-1).*r+ SEy);
%assigning all out of range pixels to have grayscale 0.
    SE(indxSE)=OORC;
    SE(indySE)=OORC;


%checking SW out of range pixels
indxSW=find(SWx<1 | SWx>r);
SWx(indxSW)=1; SWy(indxSW)=1;
indySW=find(SWy<1 | SWy>c);
SWx(indySW)=1; SWy(indySW)=1;

%picking of colors from SW pixel.
SW=im((SWx-1).*r+ SWy);
%assigning all out of range pixels to have grayscale 0.
    SW(indxSW)=OORC;
    SW(indySW)=OORC;

%calculate weighted average.
S=Dx.*SE+(1-Dx).*SW;

%checking NE out of range pixels
indxNE=find(NEx<1 | NEx>r);
NEx(indxNE)=1; NEy(indxNE)=1;
indyNE=find(NEy<1 | NEy>c);
NEx(indyNE)=1; NEy(indyNE)=1;

%picking of colors from NE pixel.
NE=im((NEx-1).*r+ NEy);
%assigning all out of range pixels to have grayscale 0.
    NE(indxNE)=OORC;
    NE(indyNE)=OORC;

%checking NW out of range pixels
indxNW=find(NWx<1 | NWx>r);
NWx(indxNW)=1; NWy(indxNW)=1;
indyNW=find(NWy<1 | NWy>c);
NWx(indyNW)=1; NWy(indyNW)=1;

%picking of colors from NW pixel.
NW=im((NWx-1).*r+ NWy);

%assigning all out of range pixels to have grayscale 0.
    NW(indxNW)=OORC;
    NW(indyNW)=OORC;

%calculate weighted average.
N=Dx.*NE+(1-Dx).*NW;
V=(Dy.*S)+((1-Dy).*N);
newIm = V;

%reshaping newIm vector into (rxc) matrix.and rounding all colors to be
%integer.
newIm = reshape(newIm,c,r);
newIm = round(newIm);

if isa(im, 'double')
    newIm = newIm ./ 255;
end
end