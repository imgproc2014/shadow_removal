function meanFacePts = calcMeanFacePts (faceFileNames)
%meanFacePts = calcMeanFacePts (faceFileNames)
%This routine calculates and returns the mean coordinates of the facial feature points of
%all points of a set of images.
%
% faceFileNames - a cell with names of all face image files to be used.
%file names are WITHOUT extensions. (e.g. file 'face1.tif' will appear as 'face1').
%
% meanFacePts  - a 24x1 vector of coordinates of the form [x1,y1,x2,y2�.]T representing
% the coordinates of the 12 average points. Points are averaged over all face images
% in the input list.
%

len=length(faceFileNames);
meanFacePts=zeros(24,1);
facepts=zeros (24,len);

%looping over all input images,for each image we save 12 points at facepts matrix.
for i=1:len
    facepts(1:24,i)=getFacePts(faceFileNames{i});
end

%calculating mean and returning a mean face points vector.
for i=1:24
    meanFacePts(i)=mean(facepts(i,1:len));
end
meanFacePts=round(meanFacePts);
end