% Warp a sequence of images to fit the first image in the sequence.
%   im_cell - Cell array of image filenames

function warped_images = warpSequenceToFirst(files, im_cell)
    global image_prefix
    
    s = size(im_cell{1});
    
    warped_images = cell(1, numel(im_cell));
    warped_images{1} = im2double(im_cell{1});
    for i = 2:numel(im_cell)
        facePts1 = getFacePts([image_prefix files(1).name], im_cell{1});
        facePts2 = getFacePts([image_prefix files(i).name], im_cell{i});

        T21 = findTransform(facePts2, facePts1);
        
        fit = mapImage(im_cell{i}, T21, s);
        warped_images{i} = fit;
    end
end

