% The function takes a cell of images and removes the shadow from them.
% It performs the algorithm shown in Yair Weiss's article 'Deriving
% intrinsic images from image sequences'.
% The function returns a single clean image 'imageR'.

% 'aligned_faces' input is the Cell of aligned face images.

function imageR = removeShadow( aligned_faces )
    %% work in the log domain
    
    faces_log = cellfun(@(x) {log((x)+1/256)}, aligned_faces);
    
    %% Derivative filters

    filters = {[1 -1] [1;-1]};  % horizental and vertical filters
    num_filters = numel(filters);
    num_faces = numel(aligned_faces);  % number of images

    %% conv
    o = cell(num_filters, num_faces);

    for i = 1:num_filters
        for j = 1:num_faces
            o{i,j} = conv2(faces_log{j}, filters{i}, 'same');
        end
    end
    
    %% median

    r_n = cell(1, num_filters);

    for i = 1:num_filters
        layers = o{i,1};
        for j = 2:num_faces
            layers = cat(3, layers, o{i,j});
        end
        r_n{i} = median(layers, 3);
    end
    
    imageR = reconsEdge3(r_n{1}, r_n{2});
end

